package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.dao.WalletDao;
import com.cg.mypaymentapp.dao.WalletDaoImpl;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;

public class WalletServiceImpl implements WalletService {
     WalletDao dao;
     public WalletServiceImpl() {
     dao=new WalletDaoImpl();	
    }
	@Override
	public Customer createAccount(String name, String mobileno,
			float amount) {


Customer c= new Customer(name, mobileno, amount);
dao.save(c);
		return c;
	}


	public Customer showBalance(String mobileno) throws InvalidInputException {
		
		// TODO Auto-generated method stub
		Customer c=dao.findOne(mobileno);
		if(c==null)
			throw new InvalidInputException("Bank Account With this Mobile Number not existed");
		return c;
	}

	

	@Override
	public Customer depositAmount(String mobileNo, float amount) {
		// TODO Auto-generated method stub
	            Customer c=dao.findOne(mobileNo);
	           
	            float curbal=c.getBalance();
	            float newbal=curbal+amount;
	            c.setBalance(newbal);
	            
	            dao.save(c);
		return c;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, float amount) throws InvalidInputException {
		// TODO Auto-generated method stub
		Customer c=dao.findOne(mobileNo);
		if(c==null){
			throw new InvalidInputException("Enter registerd mobile Number");
		}
		else{
	
		
		float curbal=c.getBalance();
		if(curbal< amount){
			throw new InsufficientBalanceException("Balance is not Sufficient to withdraw");
		}
		float newbal=curbal-amount;
		c.setBalance(newbal);
		
		dao.save(c);
		return c;
		}
	}
	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo,
			float amount) throws InvalidInputException {
		Customer c=dao.findOne(sourceMobileNo);
		
		if(c==null)
		{
			throw new InvalidInputException("Mobile Number Not registered"); 
		}
		else
		{
	
		float bal=c.getBalance();
		
		Customer c1=dao.findOne(targetMobileNo);
		if(c1==null)
		{
		throw new InvalidInputException("Mobile Number Not Registered");
		}
		else
		{
	
		float beneficiarybal=c1.getBalance();
        
		float newbal=beneficiarybal+amount;
	
		float newbal1=bal-amount;
		
		c1.setBalance(newbal);
        
        dao.save(c1);
        
		
        c.setBalance(newbal1);
       dao.save(c);
        
        
		return c;
		}
		}
		}
	@Override
	public boolean Validatename(String name) {
		
		Pattern p=Pattern.compile("[A-Z][A-Za-z ]{3,20}");
		Matcher m=p.matcher(name);
		return m.matches();
	}
	@Override
	public boolean ValidateMobileNo(String mobno) {
		// TODO Auto-generated method stub
		Pattern p=Pattern.compile("[6789][0-9]{9}");
		Matcher m=p.matcher(mobno);
		return m.matches();
	}
	@Override
	public boolean validateAmount(float amount) {
		
	if(amount>0)
		return true;
	return false;
	

}
}
