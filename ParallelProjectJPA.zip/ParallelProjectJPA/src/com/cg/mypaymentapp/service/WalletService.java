package com.cg.mypaymentapp.service;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InvalidInputException;

public interface WalletService {
	public Customer createAccount(String name ,String mobileno, float dec);
	public Customer showBalance (String mobileno) throws InvalidInputException;
	public Customer fundTransfer (String sourcemobileno,String targetmobileno, float amount) throws InvalidInputException;
	public Customer depositAmount (String mobileno,float amount );
	public Customer withdrawAmount(String mobileno, float amount) throws InvalidInputException;
	public boolean Validatename(String name);
	public boolean ValidateMobileNo(String mobno);
	public boolean validateAmount(float dec);
}
