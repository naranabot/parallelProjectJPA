package com.cg.mypaymentapp.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.mypaymentapp.beans.Customer;

public class WalletDaoImpl implements WalletDao{
	
	EntityManager manager;
	
	public WalletDaoImpl() {
		
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAQ");
			manager =emf.createEntityManager();

  }
	@Override
	public boolean save(Customer customer) {
		if(customer!=null){

		manager.getTransaction().begin();
		manager.persist(customer);
		manager.getTransaction().commit();
		
		return true;
		}
		return false;

	}

	@Override
	public Customer findOne(String mobileNo) {
		// TODO Auto-generated method stub
		
		Customer mobSearch=(Customer) manager.find(Customer.class, mobileNo);
	
		return mobSearch;
		
	
	}

}
