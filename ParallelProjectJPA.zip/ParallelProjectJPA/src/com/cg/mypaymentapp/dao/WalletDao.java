package com.cg.mypaymentapp.dao;

import com.cg.mypaymentapp.beans.Customer;

public interface WalletDao {
	

	public boolean save(Customer customer);
	
	public Customer findOne(String mobileNo);

}
