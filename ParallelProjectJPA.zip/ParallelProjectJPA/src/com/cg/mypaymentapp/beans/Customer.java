package com.cg.mypaymentapp.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CustomerDetail")
public class Customer {


	@Column(name="Name")
	private String name;
	@Id
	@Column(name="MobileNum")
	private String mobileNo;
	@Column(name="Balance")
	private float balance;
	
	public Customer(String name, String mobileNo, float balance) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.balance = balance;
	}
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", mobileNo=" + mobileNo
				+ ", balance=" + balance + "]";
	}
	
}
