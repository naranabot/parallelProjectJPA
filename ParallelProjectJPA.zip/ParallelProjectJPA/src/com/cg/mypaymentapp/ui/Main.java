package com.cg.mypaymentapp.ui;

import java.math.BigDecimal;
import java.util.Scanner;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;

public class Main {
	public static void main(String[] args) throws InvalidInputException{
		
		
		WalletService service= new WalletServiceImpl();
		Scanner sc=new Scanner(System.in);
		int ch=0;
		do{
			System.out.println("Enter your choice");
			System.out.println("1: Create Account");
			System.out.println("2: Show Balance");
			System.out.println("3: Deposit");
			System.out.println("4: Withdraw");
			System.out.println("5: Fund Transfer");
			System.out.println("6: Print Transactions");
			
			ch=sc.nextInt();
			switch(ch){
			case 1:
				System.out.println("Enter Customer Name");
                   String name= sc.next();
                 if(service.Validatename(name)==true){
                   System.out.println("Enter Mobile Number");
                   String phn=sc.next();
                    if(service.ValidateMobileNo(phn)==true){
                     System.out.println("Enter Balance");
                     float dec=sc.nextFloat();
                        if(service.validateAmount(dec)==true){
                         Customer cust=service.createAccount(name, phn, dec);
                       System.out.println(cust);
                        } 
                        else
                       	 System.out.println("Amount must be greater than 100 and less than 100000");
                     }
                    else
               	    System.out.println("Mobile Number should be 10 digit and starts with 6/7/8/9 ");
                  }
                  else
               	   System.out.println("Name should start with capital letter and min characters of 4 and max of 20");
                        
                    	
                       
                   break;
			case 2:
			  System.out.println("Enter Mobile Number");
			  String mobno=sc.next();
		if(service.ValidateMobileNo(mobno)==true){
			try{ Customer cust1=service.showBalance(mobno);
			System.out.println(cust1);
		
		}catch(InvalidInputException e){
		System.out.println(e.getMessage());
		}
		}
			 else
				  System.out.println("Mobile Number should be 10 digit and starts with 6/7/8/9");
			break;
			
			case 3:
				System.out.println("Enter Mobile Number");
				String mobno1=sc.next();
				
			if(service.ValidateMobileNo(mobno1)){	
				System.out.println("Enter the Amount to deposit");
				float dec1=sc.nextFloat();
	         if(service.validateAmount(dec1)==true){
				Customer deposit=service.depositAmount(mobno1, dec1);
				System.out.println(deposit);
	         }
				else
					System.out.println("sorry,you can transfer money from range 100 to 100000");
				}
				else
					System.out.println("Enter Beneficiary Number Correctly,Mobile Number should be 10 digit and starts with 6/7/8/9");
				break;
				
	case 4:
				
				System.out.println("Enter mobile Number");
				String mobno2=sc.next();
				if(service.ValidateMobileNo(mobno2)==true){
				  System.out.println("Enter the Amount to Withdraw");
				  float dec2=sc.nextFloat();
				    if(service.validateAmount(dec2)==true){ 
				     Customer withdraw = null;
					try {
						withdraw = service.withdrawAmount(mobno2, dec2);
					} catch (InvalidInputException e) {
						// TODO Auto-generated catch block
						System.out.println(e.getMessage());
					}
				     System.out.println(withdraw);
				
				    }
				    else 
				    	System.out.println("amount must be greater than zero");
				}
				else
					System.out.println("enter Existing Mobile number in bank,Mobile Number should be 10 digit and starts with 6/7/8/9");
				break;
				
	case 5:
				System.out.println("Enter your Mobile Number");
				String mobno3=sc.next();
				if(service.ValidateMobileNo(mobno3)==true){
				System.out.println("Enter the beneficiary number");
				String bennum=sc.next();
				if(service.ValidateMobileNo(bennum)==true){
				System.out.println("Enter the amount you want to Tranfer");
				float fund=sc.nextFloat();
				if(service.validateAmount(fund)==true){
				Customer fundtransfer = null;
				try {
					fundtransfer = service.fundTransfer(mobno3, bennum, fund);
				} catch (InvalidInputException e) {
					// TODO Auto-generated catch block
					System.out.println(e);;
				}
				System.out.println(fundtransfer);
				}
				else
					System.out.println("Amount must be greater than Zero");
				}
				else 
					System.out.println("beneficiary Mobile Number should link with his bank,mobile number should be 10 digit and starts with 6/7/8/9");
				}
				else
					System.out.println("Mobile Number should be 10 digit and starts with 6/7/8/9");
				break;
				case 6:
				System.out.println("your transactions are");
				
			case 7:
				System.out.println("You pressed the Exit Button");
			}
		}while(ch!=8);
		
		
	}
	
}