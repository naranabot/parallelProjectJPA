package com.cg.mypaymentapp.test;

import java.math.BigDecimal;

import org.junit.Assert;
import org.junit.Test;

import com.cg.mypaymentapp.service.WalletService;
import com.cg.mypaymentapp.service.WalletServiceImpl;
public class TestClass {

	

	
	 @Test
	 public void testValidateName1(){
			
			String name="naveen";
			WalletService servce=new WalletServiceImpl();
			boolean res=servce.Validatename(name);
			Assert.assertEquals(false,res);
		 }
	 @Test
	 public void testvalidateName2(){
		 String name="Naveen";
		 WalletService servce=new WalletServiceImpl();
			boolean res=servce.Validatename(name);
			Assert.assertEquals(true,res);
	 }
	 @Test
	 public void testValidateName3(){
		 String name="Naveen reddy";
		 WalletService servce=new WalletServiceImpl();
			boolean res=servce.Validatename(name);
			Assert.assertEquals(true,res);
	 }
	 @Test
	 public void testValidateMobno1(){
		 String mobNo="7661030546";
		 WalletService servce=new WalletServiceImpl();
			boolean res=servce.ValidateMobileNo(mobNo);
			Assert.assertEquals(true, res);
	 }
	 @Test
	 public void testValidateMobno2(){
		 String mobNo="0661030546";
		 WalletService servce=new WalletServiceImpl();
			boolean res=servce.ValidateMobileNo(mobNo);
			Assert.assertEquals(false, res);
	 }
	 @Test
	 public void testValidateMobno3(){
		 String mobNo="6661030546";
		 WalletService servce=new WalletServiceImpl();
			boolean res=servce.ValidateMobileNo(mobNo);
			Assert.assertEquals(true, res);
	 }
	 /*public void testValidateAmount1(){
		 WalletServiceImpl servce=new WalletServiceImpl();
		 Assert.assertEquals(true, servce.validateAmount(1000));
	 }*/
}